import UIKit

// Función para sumar dos números
func suma(primerNumero: Float, segundoNumero: Float) {
    print("Resultado de la suma de \(primerNumero) + \(segundoNumero) = \(primerNumero + segundoNumero)")
}

// Función para restar dos números
func resta(primerNumero: Float, segundoNumero: Float){
    print("Resultado de la suma de \(primerNumero) - \(segundoNumero) = \(primerNumero - segundoNumero)")
}

// Función para multiplicar dos números
func multiplicacion(primerNumero: Float, segundoNumero: Float){
    print("Resultado de la suma de \(primerNumero) x \(segundoNumero) = \(primerNumero * segundoNumero)")
}

// Función para dividir dos números
func division(primerNumero: Float, segundoNumero: Float){
    if segundoNumero == 0 {
            print("No se puede dividir entre cero")
    } else {
        print("Resultado de la suma de \(primerNumero) / \(segundoNumero) = \(primerNumero / segundoNumero)")
    }
}


func menu(){

    var opc : Int = 0
    var primerValor: Float = 0
    var segundoValor: Float = 0

     repeat {

        print("Ingrese la opción\n  0. Salir\n  1.Suma\n  2.Resta\n  3. Multiplicación\n  4. División")

        
        if let input = readLine(), let inputAsInt = Int(input) {
            opc = inputAsInt

            switch opc {
                case 1:
                    print("Ingrese el primer número:")
                    if let input = readLine(), let inputAsFloat = Float(input) {
                        primerValor = inputAsFloat
                    }
                    print("Ingrese el segundo número:")
                    if let input = readLine(), let inputAsFloat = Float(input) {
                        segundoValor = inputAsFloat
                    }
                    suma(primerNumero: primerValor, segundoNumero: segundoValor)

                case 2:
                    print("Ingrese el primer número:")
                    if let input = readLine(), let inputAsFloat = Float(input) {
                        primerValor = inputAsFloat
                    }
                    print("Ingrese el segundo número:")
                    if let input = readLine(), let inputAsFloat = Float(input) {
                        segundoValor = inputAsFloat
                    }
                    resta(primerNumero: primerValor, segundoNumero: segundoValor)

                case 3:
                    print("Ingrese el primer número:")
                    if let input = readLine(), let inputAsFloat = Float(input) {
                        primerValor = inputAsFloat
                    }
                    print("Ingrese el segundo número:")
                    if let input = readLine(), let inputAsFloat = Float(input) {
                        segundoValor = inputAsFloat
                    }
                    multiplicacion(primerNumero: primerValor, segundoNumero: segundoValor)

                case 4:
                    print("Ingrese el primer número:")
                    if let input = readLine(), let inputAsFloat = Float(input) {
                        primerValor = inputAsFloat
                    }
                    print("Ingrese el segundo número:")
                    if let input = readLine(), let inputAsFloat = Float(input) {
                        segundoValor = inputAsFloat
                    }
                    division(primerNumero: primerValor, segundoNumero: segundoValor)

                default:
                    print("Saliendo...")
                }


        } else {
            print("Opción no válida")
        }

    } while opc != 0
}

menu()
