import Foundation

// Función para sumar dos números
func suma(primerNumero: Float, segundoNumero: Float) -> Float {
    let resultado = primerNumero + segundoNumero
    return resultado
}

// Función para restar dos números
func resta(primerNumero: Float, segundoNumero: Float) -> Float {
    let resultado = primerNumero - segundoNumero
    return resultado
}

// Función para multiplicar dos números
func multiplicacion(primerNumero: Float, segundoNumero: Float) -> Float {
    let resultado = primerNumero * segundoNumero
    return resultado
}

// Función para dividir dos números
func division(primerNumero: Float, segundoNumero: Float) -> Float {
    let resultado = primerNumero / segundoNumero
    return resultado
}

// Función para mostrar el resultado de una operación
func opciones(operaciones: Int, primerValor: Float, segundoValor: Float) {
    let resultado: Float
    
    switch operaciones {
    case 1:
        resultado = suma(primerNumero: primerValor, segundoNumero: segundoValor)
        print("Resultado de la suma es -> \(resultado)")
    case 2:
        resultado = resta(primerNumero: primerValor, segundoNumero: segundoValor)
        print("Resultado de la resta es -> \(resultado)")
    case 3:
        resultado = multiplicacion(primerNumero: primerValor, segundoNumero: segundoValor)
        print("Resultado de la multiplicación es -> \(resultado)")
    case 4:
        if segundoValor == 0 {
            print("No se puede dividir entre cero")
        } else {
            resultado = division(primerNumero: primerValor, segundoNumero: segundoValor)
            print("Resultado de la división es -> \(resultado)")
        }
    default:
        print("Opción inválida")
    }
}

func menu() {
    var opc: Int = 0
    
    repeat {
        print("Ingrese la opción\n1. Suma\n2. Resta\n3. Multiplicación\n4. División\n5. Salir")
        if let opcion = readLine(), let opcionInt = Int(opcion) {
            opc = opcionInt
            
            if opc < 5 {
                print("Ingrese el primer valor: ")
                if let primerNumero = Float(readLine() ?? "") {
                    print("Ingrese el segundo valor: ")
                    if let segundoNumero = Float(readLine() ?? "") {
                        opciones(operaciones: opc, primerValor: primerNumero, segundoValor: segundoNumero)
                    } else {
                        print("Error: Segundo valor inválido")
                    }
                } else {
                    print("Error: Primer valor inválido")
                }
            }
        } else {
            print("Error: Opción inválida")
        }
    } while opc != 5
}

menu()