import Foundation

let expresion = readLine()!

var operaciones = [String]()
var numeros = [Int]()

let operacionesAceptadas = ["*", "/", "+", "-"]

var temporal = ""

for caracter in expresion{
    if operacionesAceptadas.contains(String(caracter)){

        operaciones.append(String(caracter))
        numeros.append(Int(temporal)!)
        temporal = ""
    }else{

        temporal += String(caracter)
    }

}

if !temporal.isEmpty{

    numeros.append(Int(temporal)!)
}

print(numeros)
print(operaciones)

var resultado = numeros[0]

    for i in 0..<operaciones.count {
        switch operaciones[i] {
        case "+":
            resultado += numeros[i+1]
        case "-":
            resultado -= numeros[i+1]
        case "*":
            resultado *= numeros[i+1]
        case "/":
            resultado /= numeros[i+1]
        default:
            print("Operación no válida")
            exit(1)
        }
    }

print(resultado)