//
//  MovieShows.swift
//  Cinevol2
//
//  Created by Facultad Contaduría y Administración on 22/05/23.
//
import Foundation

enum ShowTime: String {
    case ten = "10:00"
    case thirteen = "13:00"
    case fifteen = "15:00"
    case sixteen = "16:00"
    case seventeen = "17:00"
    case eighteen = "18:00"
    case nineteen = "19:00"
    case twenty = "20:00"
    case twentyOne = "21:00"
    case twentyTwo = "22:00"
    case twentyThree = "23:00"
    case twentyFour = "24:00"
    
    
}

struct MovieShow {
    
    let id: Int
    let movieId: Int
    let showTime: ShowTime
    let roomId: Int
    var seats: [Seat]
    
}

var moviesShows : [MovieShow] = [
    
    MovieShow(id: 1, movieId: 1, showTime: .ten, roomId: 1, seats: [
        Seat(seatId: 1, status: SeatStatus.empty),
        Seat(seatId: 2, status: SeatStatus.empty),
        Seat(seatId: 3, status: SeatStatus.empty),
        Seat(seatId: 4, status: SeatStatus.empty),
        Seat(seatId: 5, status: SeatStatus.empty),
        Seat(seatId: 6, status: SeatStatus.empty),
        Seat(seatId: 7, status: SeatStatus.empty),
        Seat(seatId: 8, status: SeatStatus.empty),
        Seat(seatId: 9, status: SeatStatus.empty),
        Seat(seatId: 10, status: SeatStatus.empty),
        Seat(seatId: 11, status: SeatStatus.empty),
        Seat(seatId: 12, status: SeatStatus.empty),
        Seat(seatId: 13, status: SeatStatus.empty),
        Seat(seatId: 14, status: SeatStatus.empty),
        Seat(seatId: 15, status: SeatStatus.empty),
        Seat(seatId: 16, status: SeatStatus.empty),
        
    ]),
    MovieShow(id: 2, movieId: 1, showTime: .eighteen, roomId: 2, seats: [
        Seat(seatId: 1, status: SeatStatus.empty),
        Seat(seatId: 2, status: SeatStatus.empty),
        Seat(seatId: 3, status: SeatStatus.empty),
        Seat(seatId: 4, status: SeatStatus.empty),
        Seat(seatId: 5, status: SeatStatus.empty),
        Seat(seatId: 6, status: SeatStatus.empty),
        Seat(seatId: 7, status: SeatStatus.empty),
        Seat(seatId: 8, status: SeatStatus.empty),
        Seat(seatId: 9, status: SeatStatus.empty),
        Seat(seatId: 10, status: SeatStatus.empty),
        Seat(seatId: 11, status: SeatStatus.empty),
        Seat(seatId: 12, status: SeatStatus.empty),
        Seat(seatId: 13, status: SeatStatus.empty),
        Seat(seatId: 14, status: SeatStatus.empty),
        Seat(seatId: 15, status: SeatStatus.empty),
        
    ]),
    MovieShow(id: 3, movieId: 1, showTime: .sixteen, roomId: 1, seats: [
        Seat(seatId: 1, status: SeatStatus.empty),
        Seat(seatId: 2, status: SeatStatus.empty),
        Seat(seatId: 3, status: SeatStatus.empty),
        Seat(seatId: 4, status: SeatStatus.empty),
        Seat(seatId: 5, status: SeatStatus.empty),
        Seat(seatId: 6, status: SeatStatus.empty),
        Seat(seatId: 7, status: SeatStatus.empty),
        Seat(seatId: 8, status: SeatStatus.empty),
        Seat(seatId: 9, status: SeatStatus.empty),
        Seat(seatId: 10, status: SeatStatus.empty),
        Seat(seatId: 11, status: SeatStatus.empty),
        Seat(seatId: 12, status: SeatStatus.empty),
        Seat(seatId: 13, status: SeatStatus.empty),
        Seat(seatId: 14, status: SeatStatus.empty),
        Seat(seatId: 15, status: SeatStatus.empty),
        Seat(seatId: 16, status: SeatStatus.empty),
        
    ]),
    MovieShow(id: 4, movieId: 2, showTime: .fifteen, roomId: 4, seats: [
        Seat(seatId: 1, status: SeatStatus.empty),
        Seat(seatId: 2, status: SeatStatus.empty),
        Seat(seatId: 3, status: SeatStatus.empty),
        Seat(seatId: 4, status: SeatStatus.empty),
        Seat(seatId: 5, status: SeatStatus.empty),
        Seat(seatId: 6, status: SeatStatus.empty),
        Seat(seatId: 7, status: SeatStatus.empty),
        Seat(seatId: 8, status: SeatStatus.empty),
        Seat(seatId: 9, status: SeatStatus.empty),
        Seat(seatId: 10, status: SeatStatus.empty),
        Seat(seatId: 11, status: SeatStatus.empty),
        Seat(seatId: 12, status: SeatStatus.empty),
        Seat(seatId: 13, status: SeatStatus.empty),
        Seat(seatId: 14, status: SeatStatus.empty),
        
    ]),
    MovieShow(id: 5, movieId: 3, showTime: .twenty, roomId: 3, seats: [
        Seat(seatId: 1, status: SeatStatus.empty),
        Seat(seatId: 2, status: SeatStatus.empty),
        Seat(seatId: 3, status: SeatStatus.empty),
        Seat(seatId: 4, status: SeatStatus.empty),
        Seat(seatId: 5, status: SeatStatus.empty),
        Seat(seatId: 6, status: SeatStatus.empty),
        Seat(seatId: 7, status: SeatStatus.empty),
        Seat(seatId: 8, status: SeatStatus.empty),
        Seat(seatId: 9, status: SeatStatus.empty),
        Seat(seatId: 10, status: SeatStatus.empty),
        Seat(seatId: 11, status: SeatStatus.empty),
        Seat(seatId: 12, status: SeatStatus.empty),
        Seat(seatId: 13, status: SeatStatus.empty),
        Seat(seatId: 14, status: SeatStatus.empty),
        Seat(seatId: 15, status: SeatStatus.empty),
        Seat(seatId: 16, status: SeatStatus.empty),
        Seat(seatId: 17, status: SeatStatus.empty),
        Seat(seatId: 18, status: SeatStatus.empty),
        Seat(seatId: 19, status: SeatStatus.empty),
        Seat(seatId: 20, status: SeatStatus.empty),
        Seat(seatId: 21, status: SeatStatus.empty),
    ]),
    MovieShow(id: 6, movieId: 4, showTime: .thirteen, roomId: 4, seats: [
        Seat(seatId: 1, status: SeatStatus.empty),
        Seat(seatId: 2, status: SeatStatus.empty),
        Seat(seatId: 3, status: SeatStatus.empty),
        Seat(seatId: 4, status: SeatStatus.empty),
        Seat(seatId: 5, status: SeatStatus.empty),
        Seat(seatId: 6, status: SeatStatus.empty),
        Seat(seatId: 7, status: SeatStatus.empty),
        Seat(seatId: 8, status: SeatStatus.empty),
        Seat(seatId: 9, status: SeatStatus.empty),
        Seat(seatId: 10, status: SeatStatus.empty),
        Seat(seatId: 11, status: SeatStatus.empty),
        Seat(seatId: 12, status: SeatStatus.empty),
        Seat(seatId: 13, status: SeatStatus.empty),
        Seat(seatId: 14, status: SeatStatus.empty),
        
    ]),
    MovieShow(id: 7, movieId: 4, showTime: .twentyFour, roomId: 2, seats: [
        Seat(seatId: 1, status: SeatStatus.empty),
        Seat(seatId: 2, status: SeatStatus.empty),
        Seat(seatId: 3, status: SeatStatus.empty),
        Seat(seatId: 4, status: SeatStatus.empty),
        Seat(seatId: 5, status: SeatStatus.empty),
        Seat(seatId: 6, status: SeatStatus.empty),
        Seat(seatId: 7, status: SeatStatus.empty),
        Seat(seatId: 8, status: SeatStatus.empty),
        Seat(seatId: 9, status: SeatStatus.empty),
        Seat(seatId: 10, status: SeatStatus.empty),
        Seat(seatId: 11, status: SeatStatus.empty),
        Seat(seatId: 12, status: SeatStatus.empty),
        Seat(seatId: 13, status: SeatStatus.empty),
        Seat(seatId: 14, status: SeatStatus.empty),
        Seat(seatId: 15, status: SeatStatus.empty),
        
    ]),
    MovieShow(id: 8, movieId: 5, showTime: .ten, roomId: 3, seats: [
        Seat(seatId: 1, status: SeatStatus.empty),
        Seat(seatId: 2, status: SeatStatus.empty),
        Seat(seatId: 3, status: SeatStatus.empty),
        Seat(seatId: 4, status: SeatStatus.empty),
        Seat(seatId: 5, status: SeatStatus.empty),
        Seat(seatId: 6, status: SeatStatus.empty),
        Seat(seatId: 7, status: SeatStatus.empty),
        Seat(seatId: 8, status: SeatStatus.empty),
        Seat(seatId: 9, status: SeatStatus.empty),
        Seat(seatId: 10, status: SeatStatus.empty),
        Seat(seatId: 11, status: SeatStatus.empty),
        Seat(seatId: 12, status: SeatStatus.empty),
        Seat(seatId: 13, status: SeatStatus.empty),
        Seat(seatId: 14, status: SeatStatus.empty),
        Seat(seatId: 15, status: SeatStatus.empty),
        Seat(seatId: 16, status: SeatStatus.empty),
        Seat(seatId: 17, status: SeatStatus.empty),
        Seat(seatId: 18, status: SeatStatus.empty),
        Seat(seatId: 19, status: SeatStatus.empty),
        Seat(seatId: 20, status: SeatStatus.empty),
        Seat(seatId: 21, status: SeatStatus.empty),
    ]),
    MovieShow(id: 9, movieId: 6, showTime: .twentyTwo, roomId: 1, seats: [
        Seat(seatId: 1, status: SeatStatus.empty),
        Seat(seatId: 2, status: SeatStatus.empty),
        Seat(seatId: 3, status: SeatStatus.empty),
        Seat(seatId: 4, status: SeatStatus.empty),
        Seat(seatId: 5, status: SeatStatus.empty),
        Seat(seatId: 6, status: SeatStatus.empty),
        Seat(seatId: 7, status: SeatStatus.empty),
        Seat(seatId: 8, status: SeatStatus.empty),
        Seat(seatId: 9, status: SeatStatus.empty),
        Seat(seatId: 10, status: SeatStatus.empty),
        Seat(seatId: 11, status: SeatStatus.empty),
        Seat(seatId: 12, status: SeatStatus.empty),
        Seat(seatId: 13, status: SeatStatus.empty),
        Seat(seatId: 14, status: SeatStatus.empty),
        Seat(seatId: 15, status: SeatStatus.empty),
        Seat(seatId: 16, status: SeatStatus.empty),
        
        
    ]),
    MovieShow(id: 10, movieId: 7, showTime: .seventeen, roomId: 2, seats: [
        Seat(seatId: 1, status: SeatStatus.empty),
        Seat(seatId: 2, status: SeatStatus.empty),
        Seat(seatId: 3, status: SeatStatus.empty),
        Seat(seatId: 4, status: SeatStatus.empty),
        Seat(seatId: 5, status: SeatStatus.empty),
        Seat(seatId: 6, status: SeatStatus.empty),
        Seat(seatId: 7, status: SeatStatus.empty),
        Seat(seatId: 8, status: SeatStatus.empty),
        Seat(seatId: 9, status: SeatStatus.empty),
        Seat(seatId: 10, status: SeatStatus.empty),
        Seat(seatId: 11, status: SeatStatus.empty),
        Seat(seatId: 12, status: SeatStatus.empty),
        Seat(seatId: 13, status: SeatStatus.empty),
        Seat(seatId: 14, status: SeatStatus.empty),
        Seat(seatId: 15, status: SeatStatus.empty),
        
    ]),
    MovieShow(id: 11, movieId: 1, showTime: .seventeen, roomId: 4, seats: [
        Seat(seatId: 1, status: SeatStatus.empty),
        Seat(seatId: 2, status: SeatStatus.empty),
        Seat(seatId: 3, status: SeatStatus.empty),
        Seat(seatId: 4, status: SeatStatus.empty),
        Seat(seatId: 5, status: SeatStatus.empty),
        Seat(seatId: 6, status: SeatStatus.empty),
        Seat(seatId: 7, status: SeatStatus.empty),
        Seat(seatId: 8, status: SeatStatus.empty),
        Seat(seatId: 9, status: SeatStatus.empty),
        Seat(seatId: 10, status: SeatStatus.empty),
        Seat(seatId: 11, status: SeatStatus.empty),
        Seat(seatId: 12, status: SeatStatus.empty),
        Seat(seatId: 13, status: SeatStatus.empty),
        Seat(seatId: 14, status: SeatStatus.empty),
        
    ]),
    MovieShow(id: 12, movieId: 2, showTime: .fifteen, roomId: 1, seats: [
        Seat(seatId: 1, status: SeatStatus.empty),
        Seat(seatId: 2, status: SeatStatus.empty),
        Seat(seatId: 3, status: SeatStatus.empty),
        Seat(seatId: 4, status: SeatStatus.empty),
        Seat(seatId: 5, status: SeatStatus.empty),
        Seat(seatId: 6, status: SeatStatus.empty),
        Seat(seatId: 7, status: SeatStatus.empty),
        Seat(seatId: 8, status: SeatStatus.empty),
        Seat(seatId: 9, status: SeatStatus.empty),
        Seat(seatId: 10, status: SeatStatus.empty),
        Seat(seatId: 11, status: SeatStatus.empty),
        Seat(seatId: 12, status: SeatStatus.empty),
        Seat(seatId: 13, status: SeatStatus.empty),
        Seat(seatId: 14, status: SeatStatus.empty),
        Seat(seatId: 15, status: SeatStatus.empty),
        Seat(seatId: 16, status: SeatStatus.empty),
        
    ]),
    MovieShow(id: 13, movieId: 2, showTime: .sixteen, roomId: 2, seats: [
        Seat(seatId: 1, status: SeatStatus.empty),
        Seat(seatId: 2, status: SeatStatus.empty),
        Seat(seatId: 3, status: SeatStatus.empty),
        Seat(seatId: 4, status: SeatStatus.empty),
        Seat(seatId: 5, status: SeatStatus.empty),
        Seat(seatId: 6, status: SeatStatus.empty),
        Seat(seatId: 7, status: SeatStatus.empty),
        Seat(seatId: 8, status: SeatStatus.empty),
        Seat(seatId: 9, status: SeatStatus.empty),
        Seat(seatId: 10, status: SeatStatus.empty),
        Seat(seatId: 11, status: SeatStatus.empty),
        Seat(seatId: 12, status: SeatStatus.empty),
        Seat(seatId: 13, status: SeatStatus.empty),
        Seat(seatId: 14, status: SeatStatus.empty),
        Seat(seatId: 15, status: SeatStatus.empty),
        
    ]),
    MovieShow(id: 14, movieId: 3, showTime: .thirteen, roomId: 3, seats: [
        Seat(seatId: 1, status: SeatStatus.empty),
        Seat(seatId: 2, status: SeatStatus.empty),
        Seat(seatId: 3, status: SeatStatus.empty),
        Seat(seatId: 4, status: SeatStatus.empty),
        Seat(seatId: 5, status: SeatStatus.empty),
        Seat(seatId: 6, status: SeatStatus.empty),
        Seat(seatId: 7, status: SeatStatus.empty),
        Seat(seatId: 8, status: SeatStatus.empty),
        Seat(seatId: 9, status: SeatStatus.empty),
        Seat(seatId: 10, status: SeatStatus.empty),
        Seat(seatId: 11, status: SeatStatus.empty),
        Seat(seatId: 12, status: SeatStatus.empty),
        Seat(seatId: 13, status: SeatStatus.empty),
        Seat(seatId: 14, status: SeatStatus.empty),
        Seat(seatId: 15, status: SeatStatus.empty),
        Seat(seatId: 16, status: SeatStatus.empty),
        Seat(seatId: 17, status: SeatStatus.empty),
        Seat(seatId: 18, status: SeatStatus.empty),
        Seat(seatId: 19, status: SeatStatus.empty),
        Seat(seatId: 20, status: SeatStatus.empty),
        Seat(seatId: 21, status: SeatStatus.empty),
    ]),
    MovieShow(id: 15, movieId: 3, showTime: .eighteen, roomId: 4, seats: [
        Seat(seatId: 1, status: SeatStatus.empty),
        Seat(seatId: 2, status: SeatStatus.empty),
        Seat(seatId: 3, status: SeatStatus.empty),
        Seat(seatId: 4, status: SeatStatus.empty),
        Seat(seatId: 5, status: SeatStatus.empty),
        Seat(seatId: 6, status: SeatStatus.empty),
        Seat(seatId: 7, status: SeatStatus.empty),
        Seat(seatId: 8, status: SeatStatus.empty),
        Seat(seatId: 9, status: SeatStatus.empty),
        Seat(seatId: 10, status: SeatStatus.empty),
        Seat(seatId: 11, status: SeatStatus.empty),
        Seat(seatId: 12, status: SeatStatus.empty),
        Seat(seatId: 13, status: SeatStatus.empty),
        Seat(seatId: 14, status: SeatStatus.empty),
        
    ]),
    MovieShow(id: 16, movieId: 4, showTime: .nineteen, roomId: 2, seats: [
        Seat(seatId: 1, status: SeatStatus.empty),
        Seat(seatId: 2, status: SeatStatus.empty),
        Seat(seatId: 3, status: SeatStatus.empty),
        Seat(seatId: 4, status: SeatStatus.empty),
        Seat(seatId: 5, status: SeatStatus.empty),
        Seat(seatId: 6, status: SeatStatus.empty),
        Seat(seatId: 7, status: SeatStatus.empty),
        Seat(seatId: 8, status: SeatStatus.empty),
        Seat(seatId: 9, status: SeatStatus.empty),
        Seat(seatId: 10, status: SeatStatus.empty),
        Seat(seatId: 11, status: SeatStatus.empty),
        Seat(seatId: 12, status: SeatStatus.empty),
        Seat(seatId: 13, status: SeatStatus.empty),
        Seat(seatId: 14, status: SeatStatus.empty),
        Seat(seatId: 15, status: SeatStatus.empty),
        
    ]),
    MovieShow(id: 17, movieId: 7, showTime: .twentyTwo, roomId: 3, seats: [
        Seat(seatId: 1, status: SeatStatus.empty),
        Seat(seatId: 2, status: SeatStatus.empty),
        Seat(seatId: 3, status: SeatStatus.empty),
        Seat(seatId: 4, status: SeatStatus.empty),
        Seat(seatId: 5, status: SeatStatus.empty),
        Seat(seatId: 6, status: SeatStatus.empty),
        Seat(seatId: 7, status: SeatStatus.empty),
        Seat(seatId: 8, status: SeatStatus.empty),
        Seat(seatId: 9, status: SeatStatus.empty),
        Seat(seatId: 10, status: SeatStatus.empty),
        Seat(seatId: 11, status: SeatStatus.empty),
        Seat(seatId: 12, status: SeatStatus.empty),
        Seat(seatId: 13, status: SeatStatus.empty),
        Seat(seatId: 14, status: SeatStatus.empty),
        Seat(seatId: 15, status: SeatStatus.empty),
        Seat(seatId: 16, status: SeatStatus.empty),
        Seat(seatId: 17, status: SeatStatus.empty),
        Seat(seatId: 18, status: SeatStatus.empty),
        Seat(seatId: 19, status: SeatStatus.empty),
        Seat(seatId: 20, status: SeatStatus.empty),
        Seat(seatId: 21, status: SeatStatus.empty),
    ]),
    
    
]




